package restApi.api.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import restApi.api.model.Item;
import restApi.api.repository.ItemRepository;
import restApi.api.service.ItemService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ItemServiceImpl implements ItemService {

    private final ItemRepository itemRepository;

    @Override
    public List<Item> getAll() {
        return itemRepository.findAll();
    }

    @Override
    public Item getById(Long id) {
        return itemRepository.findById(id).orElse(null);
    }

    @Override
    public void addItem(Item item) {
        itemRepository.save(item);
    }

    @Override
    public void updateItem(Long id, Item item) {
        Item updateItem = itemRepository.findById(id).orElse(null);

        updateItem.setName(item.getName());
        updateItem.setDescription(item.getDescription());
        updateItem.setPrice(item.getPrice());
        updateItem.setCategory(item.getCategory());

        itemRepository.save(updateItem);
    }

    @Override
    public void deleteItem(Long id) {
        itemRepository.deleteById(id);
    }
}
