package restApi.api.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import restApi.api.model.Category;
import restApi.api.repository.CategoryRepository;
import restApi.api.service.CategoryService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;


    @Override
    public List<Category> getAll() {
        return categoryRepository.findAll();
    }

    @Override
    public void addCategory(Category category) {
        categoryRepository.save(category);
    }

    @Override
    public void updateCategory(Long id, Category category) {
        Category update = categoryRepository.findById(id).orElse(null);
        update.setName(category.getName());
        categoryRepository.save(update);
    }
}
