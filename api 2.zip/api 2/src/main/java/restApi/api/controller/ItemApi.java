package restApi.api.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import restApi.api.model.Item;
import restApi.api.service.ItemService;

@RestController
@RequiredArgsConstructor
@RequestMapping("/item")
public class ItemApi {

    private final ItemService itemService;

    @GetMapping
    public ResponseEntity<?> getAll(){
        return new ResponseEntity<>(itemService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable(name = "id") Long id){
        return new ResponseEntity<>(itemService.getById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> addItem(@RequestBody Item item){
        itemService.addItem(item);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateItem(@PathVariable(name = "id") Long id,
                                        @RequestBody Item item){
        itemService.updateItem(id, item);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteItem(@PathVariable(name = "id") Long id){
        itemService.deleteItem(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
